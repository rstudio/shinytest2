library(testthat)
library(shinytest2)

test_check("shinytest2")
