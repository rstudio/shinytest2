# JS can take a file or script

    "testExpectJs"

