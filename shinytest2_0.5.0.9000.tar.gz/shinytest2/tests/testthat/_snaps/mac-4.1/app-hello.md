# basic website example works using shinytest

    "Hello Hadley!"

---

    "<div id=\"greeting\" class=\"shiny-text-output shiny-bound-output\" aria-live=\"polite\">Hello Hadley!<\/div>"

