#' @useDynLib shinytest2, .registration = TRUE
NULL

release_bullets <- function() {
  c(
    "Is the `actions/test-app` sliding tag up-to-date? Check both `v1` and `actions/v1`."
  )
}
